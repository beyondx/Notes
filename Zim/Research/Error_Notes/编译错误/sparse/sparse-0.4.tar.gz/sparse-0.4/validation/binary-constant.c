extern int x;

int x = 0b11;

/*
 * check-name: inline compound literals
 */
